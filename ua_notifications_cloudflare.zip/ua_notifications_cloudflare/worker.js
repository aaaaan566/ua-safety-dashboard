const SOURCES = [
  { channel: "berestyntruvoga_neoffcanal", group: "threat" },
  { channel: "monitor1654", group: "threat" },
  { channel: "tlknewsua", group: "threat" },
  { channel: "kharkivenergy", group: "light" },
  { channel: "kh_alerts", group: "air" }
];

const DISTRICTS = [
  "Берестинський район", "Богодухівський район", "Ізюмський район",
  "Куп’янський район", "Лозівський район", "Харківський район", "Чугуївський район"
];

const PAGE = `<!doctype html>
<html lang="uk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101827"><title>UA Safety Dashboard</title>
<style>
:root{color-scheme:dark;--bg:#0b1220;--panel:#121d2e;--line:#26364c;--muted:#9aabc1;--white:#f4f7fb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--white);font:15px system-ui,-apple-system,Segoe UI,sans-serif}
header{padding:22px 18px 16px;border-bottom:1px solid var(--line);background:#101a2a}
h1{font-size:22px;margin:0 0 5px}.sub{color:var(--muted);font-size:13px}
main{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;padding:16px;max-width:1500px;margin:auto}
section{background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;min-height:300px}
.section-head{padding:16px;border-bottom:1px solid var(--line);font-weight:700}
.section-head small{display:block;color:var(--muted);font-weight:400;margin-top:4px}
.items{padding:10px;display:grid;gap:9px}.item{padding:12px;border:1px solid var(--line);border-radius:12px;background:#0e1828}
.meta{font-size:11px;color:var(--muted);display:flex;justify-content:space-between;gap:8px;margin-bottom:7px}
.message{line-height:1.45;overflow-wrap:anywhere}.source{color:#9fc4ff;text-decoration:none}.source:active{text-decoration:underline}
.empty{color:var(--muted);padding:16px;font-size:13px}
.district{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:11px;border:1px solid var(--line);border-radius:11px;background:#0e1828}
.status{font-size:12px;font-weight:700;border-radius:20px;padding:5px 9px;white-space:nowrap}
.red{background:#5b2028;color:#ffc1c5}.green{background:#173e31;color:#b8f2d4}.unknown{background:#344154;color:#d4deeb}
.foot{padding:0 16px 16px;color:var(--muted);font-size:12px;text-align:center}
@media(max-width:850px){main{grid-template-columns:1fr}.section{min-height:0}header{padding:18px 14px}}
</style></head><body>
<header><h1>UA Safety Dashboard</h1><div class="sub">Харківська область · автоматичне оновлення</div></header>
<main>
<section><div class="section-head">⚠️ Загроза для Харківської області<small>Загальні цивільні попередження та інформація</small></div><div id="threat" class="items"><div class="empty">Очікування даних із сервера…</div></div></section>
<section><div class="section-head">💡 Світло<small>Відключення та відновлення електропостачання</small></div><div id="light" class="items"><div class="empty">Очікування даних із сервера…</div></div></section>
<section><div class="section-head">🚨 Повітряні тривоги<small>Статуси районів Харківської області</small></div><div id="air" class="items"></div></section>
</main><div class="foot" id="updated">Дані ще не отримані. Статуси не підмінюються припущеннями.</div>
<script>
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function renderList(id,items){const el=document.getElementById(id);el.innerHTML=items.length?items.map(x=>\`<article class="item"><div class="meta"><span>\${esc(x.source)}</span><span>\${esc(x.time)}</span></div><div class="message">\${esc(x.text)}</div><div class="meta" style="margin:8px 0 0"><a class="source" href="\${esc(x.url)}" target="_blank" rel="noopener">Відкрити повідомлення ↗</a></div></article>\`).join(""):'<div class="empty">Поки немає підтверджених повідомлень.</div>'}
async function load(){try{const r=await fetch('/api/feed',{cache:'no-store'});if(!r.ok)throw Error('API '+r.status);const d=await r.json();renderList('threat',d.threat||[]);renderList('light',d.light||[]);const a=d.air||{};document.getElementById('air').innerHTML=(d.districts||[]).map(n=>{const s=a[n];const cls=s?.status==='alert'?'red':s?.status==='clear'?'green':'unknown';const label=s?.status==='alert'?'ТРИВОГА':s?.status==='clear'?'ВІДБІЙ':'НЕМАЄ ДАНИХ';const link=s?.url?\`<a class="source" href="\${esc(s.url)}" target="_blank" rel="noopener">Джерело ↗</a>\`:'';return \`<div class="district"><span>\${esc(n)}</span><span class="status \${cls}">\${label}</span></div>\${link?\`<div class="meta">\${link}<span>\${esc(s.time||'')}</span></div>\`:''}\`}).join('');document.getElementById('updated').textContent='Останнє оновлення сервера: '+(d.updated||'невідомо')+' · Сайт оновлює дані кожні 30 секунд.'}catch(e){document.getElementById('updated').textContent='Немає зв’язку із сервером. Перевірте пізніше.'}}
load();setInterval(load,30000);
</script></body></html>`;

function cleanText(s) {
  return s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/\s+/g, " ").trim();
}
function isUnsafeMilitaryContent(t) {
  return /(шахед|shahed|герань|гербера|бпла|дрон|безпілотник|ракета|баліст|крилат|гіперзву|каб\b|авіабомб|бандерол|реактивн|курс(ом)? на|летить у напрям|рухається в напрям|прямує до|зафіксовано рух)/iu.test(t);
}
function extractPosts(html, channel) {
  const out = [];
  const blocks = html.match(/<div class="tgme_widget_message_wrap[\s\S]*?(?=<div class="tgme_widget_message_wrap|$)/g) || [];
  for (const b of blocks) {
    const id = b.match(/data-post="([^"]+)"/)?.[1];
    const raw = b.match(/<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/)?.[1];
    if (!id || !raw) continue;
    const text = cleanText(raw);
    const date = b.match(/<time[^>]*datetime="([^"]+)"/)?.[1] || "";
    const msgId = id.split("/").pop();
    out.push({ id, text, time: date ? new Date(date).toLocaleString("uk-UA",{timeZone:"Europe/Kyiv"}) : "", url:`https://t.me/${id}`, source:`@${channel}`, msgId:Number(msgId)||0 });
  }
  return out;
}
function districtFor(t) {
  const low=t.toLocaleLowerCase("uk");
  const aliases = [
    ["Берестинський район",/берестинськ/],["Богодухівський район",/богодухівськ/],
    ["Ізюмський район",/ізюмськ/],["Куп’янський район",/куп.?янськ/],
    ["Лозівський район",/лозівськ/],["Харківський район",/харківськ/],
    ["Чугуївський район",/чугуївськ/]
  ];
  return aliases.find(x=>x[1].test(low))?.[0] || null;
}
function classify(posts, group) {
  const result=[];
  for(const p of posts) {
    const t=p.text;
    if(group==="threat") {
      if(isUnsafeMilitaryContent(t)) continue;
      if(!/(увага|попереджен|небезпек|укрит|обережн|загроз|цивільн|населен|повідомляємо)/iu.test(t)) continue;
      result.push({...p, text:t.slice(0,700)});
    } else if(group==="light") {
      if(!/(світл|електроенерг|електропостач|відключ|знеструм|енергетик|електри)/iu.test(t)) continue;
      result.push({...p,text:t.slice(0,700)});
    }
  }
  return result;
}
async function fetchChannel(channel, group) {
  const res=await fetch(`https://t.me/s/${channel}`,{headers:{"User-Agent":"Mozilla/5.0 UA-Safety-Dashboard/1.0"},cf:{cacheTtl:0}});
  if(!res.ok) throw new Error(`${channel}: HTTP ${res.status}`);
  const posts=extractPosts(await res.text(),channel);
  return {group,posts};
}
async function refresh(env) {
  const settled=await Promise.allSettled(SOURCES.map(s=>fetchChannel(s.channel,s.group)));
  const feed={threat:[],light:[],air:{},districts:DISTRICTS,updated:new Date().toLocaleString("uk-UA",{timeZone:"Europe/Kyiv"}),errors:[]};
  for(let i=0;i<settled.length;i++){
    const r=settled[i], source=SOURCES[i];
    if(r.status!=="fulfilled"){feed.errors.push(`${source.channel}: джерело тимчасово недоступне`);continue;}
    const posts=r.value.posts;
    if(source.group==="threat") feed.threat.push(...classify(posts,"threat"));
    if(source.group==="light") feed.light.push(...classify(posts,"light"));
    if(source.group==="air"){
      for(const p of posts){
        const d=districtFor(p.text); if(!d) continue;
        const t=p.text;
        if(isUnsafeMilitaryContent(t)) continue;
        let status=null;
        if(/(відбій повітряної тривоги|тривогу скасовано|відбій тривоги)/iu.test(t)) status="clear";
        else if(/(повітряна тривога|оголошено тривогу|увага.*тривога)/iu.test(t)) status="alert";
        if(status && (!feed.air[d] || p.msgId>feed.air[d].msgId)) feed.air[d]={status,url:p.url,time:p.time,msgId:p.msgId};
      }
    }
  }
  const sort=(a,b)=>b.msgId-a.msgId;
  feed.threat=feed.threat.sort(sort).slice(0,25);
  feed.light=feed.light.sort(sort).slice(0,25);
  const previous=await env.FEED.get("latest");
  let shouldWrite=!previous;
  if(previous){
    try {
      const old=JSON.parse(previous);
      const comparable=x=>JSON.stringify({...x,updated:null});
      shouldWrite=comparable(old)!==comparable(feed) ||
        (Date.now()-(Date.parse(old.updated)||0))>5*60*1000;
    } catch { shouldWrite=true; }
  }
  if(shouldWrite) await env.FEED.put("latest",JSON.stringify(feed));
  return feed;
}
export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    if(url.pathname==="/api/feed"){
      const data=await env.FEED.get("latest");
      return new Response(data||JSON.stringify({threat:[],light:[],air:{},districts:DISTRICTS,updated:null,errors:["Ожидается первый запуск фоновой проверки"]}),{headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","access-control-allow-origin":"*"}});
    }
    if(url.pathname==="/api/health"){
      const h=await env.FEED.get("latest");
      let result={status:"waiting for first scheduled check"};
      if(h){const d=JSON.parse(h);result={status:"ok",lastSavedUpdate:d.updated,sourceErrors:d.errors||[]};}
      return new Response(JSON.stringify(result),{headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
    }
    return new Response(PAGE,{headers:{"content-type":"text/html; charset=utf-8","cache-control":"no-store"}});
  },
  async scheduled(controller,env,ctx) {
    await refresh(env);
  }
};
